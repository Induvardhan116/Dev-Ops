import { useState } from 'react'
import { Search, SlidersHorizontal, Sparkles } from 'lucide-react'
import Header from './components/Header.jsx'
import ProductList from './components/ProductList.jsx'
import Cart from './components/Cart.jsx'
import { products as productCatalog } from './data/products.js'
import './App.css'

const categories = ['All things', 'Electronics', 'Accessories']

export default function App() {
  const [cart, setCart] = useState([])
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All things')

  const addToCart = (product) => {
    setCart((currentCart) => {
      const existingItem = currentCart.find((item) => item.id === product.id)
      if (existingItem) {
        return currentCart.map((item) => item.id === product.id
          ? { ...item, cartQuantity: Math.min(item.cartQuantity + 1, item.quantity) }
          : item)
      }
      return [...currentCart, { ...product, cartQuantity: 1 }]
    })
  }

  const changeQuantity = (productId, quantity) => {
    setCart((currentCart) => currentCart.map((item) => item.id === productId
      ? { ...item, cartQuantity: Math.min(Math.max(quantity, 1), item.quantity) }
      : item))
  }

  const removeFromCart = (productId) => {
    setCart((currentCart) => currentCart.filter((item) => item.id !== productId))
  }

  const itemCount = cart.reduce((count, item) => count + item.cartQuantity, 0)
  const subtotal = cart.reduce((amount, item) => amount + item.price * item.cartQuantity, 0)
  const discount = subtotal > 5000 ? Math.round(subtotal * 0.1) : 0
  const delivery = subtotal === 0 || subtotal > 2000 ? 0 : 120
  const totalAmount = subtotal - discount + delivery

  const visibleProducts = productCatalog.filter((product) => {
    const matchesCategory = category === 'All things' || product.category === category
    const searchableText = `${product.name} ${product.category} ${product.id}`.toLowerCase()
    return matchesCategory && searchableText.includes(search.trim().toLowerCase())
  })

  return (
    <div className="app-shell" id="top">
      <Header itemCount={itemCount} />

      <main className="page-layout">
        <section className="shop-section" id="shop" aria-labelledby="shop-title">
          <div className="shop-intro">
            <div className="intro-copy">
              <span className="eyebrow intro-eyebrow"><Sparkles size={13} /> THE EVERYDAY COLLECTION</span>
              <h1 id="shop-title">Find your <em>good thing.</em></h1>
              <p>Useful, lovely things for wherever the day takes you.</p>
            </div>
            <div className="intro-stamp" aria-hidden="true"><span>GOOD<br />THINGS</span><span className="stamp-star">✳</span></div>
          </div>

          <div className="catalog-toolbar">
            <label className="search-field">
              <Search size={17} />
              <input
                type="search"
                placeholder="Find something..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                aria-label="Search products"
              />
              {search && <button type="button" className="search-clear" onClick={() => setSearch('')} aria-label="Clear search">×</button>}
            </label>
            <div className="category-filter" role="group" aria-label="Filter by category">
              <span className="filter-icon"><SlidersHorizontal size={15} /></span>
              {categories.map((item) => (
                <button
                  className={`filter-button${category === item ? ' selected' : ''}`}
                  key={item}
                  type="button"
                  onClick={() => setCategory(item)}
                  aria-pressed={category === item}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <div className="results-line">
            <span>{category === 'All things' ? 'A few of our favourites' : category}</span>
            <span>{visibleProducts.length.toString().padStart(2, '0')} FINDS</span>
          </div>
          <ProductList products={visibleProducts} onAdd={addToCart} cart={cart} />
          <footer className="shop-footer"><span>GOOD THINGS, CHOSEN WELL.</span><span>Made for your everyday <span className="footer-spark">✳</span></span></footer>
        </section>

        <Cart
          cart={cart}
          onQuantityChange={changeQuantity}
          onRemove={removeFromCart}
          onClear={() => setCart([])}
          subtotal={subtotal}
          discount={discount}
          delivery={delivery}
          totalAmount={totalAmount}
          itemCount={itemCount}
        />
      </main>
    </div>
  )
}