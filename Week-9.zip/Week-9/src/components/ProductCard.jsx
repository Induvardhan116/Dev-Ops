import { Check, Plus } from 'lucide-react'

const money = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
})

export default function ProductCard({ product, onAdd, inCart }) {
  const isSoldOut = product.quantity === 0

  return (
    <article className="product-card">
      <div className={`product-image-wrap tone-${product.tone}`}>
        <img className="product-image" src={product.image} alt={product.name} loading="lazy" />
        <span className="product-category">{product.category}</span>
        {inCart && <span className="in-bag"><Check size={13} /> In your bag</span>}
      </div>
      <div className="product-meta">
        <div className="product-heading">
          <h3>{product.name}</h3>
          <span className="product-id">{product.id}</span>
        </div>
        <p className="product-description">{product.description}</p>
        <div className="product-bottom">
          <div>
            <strong className="product-price">{money.format(product.price)}</strong>
            <span className="stock-note">{product.quantity} in stock</span>
          </div>
          <button
            className={`add-button${inCart ? ' added' : ''}`}
            type="button"
            onClick={() => onAdd(product)}
            disabled={isSoldOut}
            aria-label={`${inCart ? 'Add another' : 'Add'} ${product.name} to cart`}
            title={isSoldOut ? 'Out of stock' : inCart ? 'Add one more' : 'Add to bag'}
          >
            {inCart ? <Check size={17} /> : <Plus size={18} />}
          </button>
        </div>
      </div>
    </article>
  )
}