import { ArrowRight, Tag, Truck } from 'lucide-react'

const money = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
})

export default function Summary({ itemCount, subtotal, discount, delivery, totalAmount }) {
  const remainingForFreeDelivery = Math.max(0, 2000 - subtotal)

  return (
    <div className="summary">
      <div className={`delivery-message${delivery === 0 ? ' delivery-earned' : ''}`}>
        <Truck size={17} />
        <span>{delivery === 0 ? 'Free delivery is yours' : `Add ${money.format(remainingForFreeDelivery)} for free delivery`}</span>
      </div>
      <div className="summary-lines">
        <div><span>Subtotal <small>({itemCount} {itemCount === 1 ? 'item' : 'items'})</small></span><strong>{money.format(subtotal)}</strong></div>
        {discount > 0 && <div className="discount-line"><span><Tag size={14} /> Cart discount (10%)</span><strong>−{money.format(discount)}</strong></div>}
        <div><span>Delivery</span><strong>{delivery === 0 ? <span className="free-label">Free</span> : money.format(delivery)}</strong></div>
      </div>
      <div className="summary-total">
        <span>Total</span>
        <strong>{money.format(totalAmount)}</strong>
      </div>
      <button className="checkout-button" type="button" onClick={() => window.alert('Thanks for shopping with Good Things!')}>
        Continue to checkout <ArrowRight size={17} />
      </button>
      <p className="checkout-caption">Taxes included · Secure checkout</p>
    </div>
  )
}