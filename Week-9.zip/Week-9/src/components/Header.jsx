import { ShoppingBag } from 'lucide-react'

export default function Header({ itemCount }) {
  return (
    <header className="site-header">
      <a className="wordmark" href="#top" aria-label="Good Things home">
        <span className="wordmark-mark">g.</span>
        <span>good things<span className="wordmark-period">.</span></span>
      </a>
      <div className="header-note">A little shop for everyday life</div>
      <a className="header-cart" href="#your-cart" aria-label={`Your bag, ${itemCount} items`}>
        <ShoppingBag size={18} strokeWidth={1.8} />
        <span className="header-cart-label">Your bag</span>
        <span className="header-count">{itemCount}</span>
      </a>
    </header>
  )
}