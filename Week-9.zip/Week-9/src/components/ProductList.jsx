import ProductCard from './ProductCard.jsx'

export default function ProductList({ products, onAdd, cart }) {
  if (products.length === 0) {
    return (
      <div className="no-results">
        <span className="no-results-mark">?</span>
        <h3>Nothing on this shelf</h3>
        <p>Try a different search or category.</p>
      </div>
    )
  }

  return (
    <div className="product-grid">
      {products.map((product) => (
        <ProductCard
          key={product.id}
          product={product}
          name={product.name}
          price={product.price}
          category={product.category}
          onAdd={onAdd}
          inCart={cart.some((item) => item.id === product.id)}
        />
      ))}
    </div>
  )
}