import { ShoppingBag, Sparkles } from 'lucide-react'
import CartItem from './CartItem.jsx'
import Summary from './Summary.jsx'

export default function Cart({ cart, onQuantityChange, onRemove, onClear, subtotal, discount, delivery, totalAmount, itemCount }) {
  return (
    <aside className="cart-panel" id="your-cart" aria-label="Shopping cart">
      <div className="cart-heading">
        <div>
          <span className="eyebrow">YOUR LITTLE EDIT</span>
          <h2>Your bag <span className="cart-heading-count">{itemCount}</span></h2>
        </div>
        {cart.length > 0 && (
          <button className="clear-button" type="button" onClick={onClear}>Clear all</button>
        )}
      </div>

      {cart.length === 0 ? (
        <div className="empty-cart">
          <div className="empty-cart-icon"><ShoppingBag size={22} strokeWidth={1.5} /></div>
          <h3>Your bag is taking a breather</h3>
          <p>Find something lovely and it will show up here.</p>
          <a href="#shop">Explore the collection <span>↓</span></a>
        </div>
      ) : (
        <>
          <ul className="cart-list">
            {cart.map((item) => (
              <CartItem
                key={item.id}
                item={item}
                quantity={item.cartQuantity}
                price={item.price}
                onQuantityChange={onQuantityChange}
                onRemove={onRemove}
              />
            ))}
          </ul>
          <Summary
            itemCount={itemCount}
            subtotal={subtotal}
            discount={discount}
            delivery={delivery}
            totalAmount={totalAmount}
          />
          {discount > 0 && <p className="discount-note"><Sparkles size={14} /> A little thank-you, on us.</p>}
        </>
      )}
    </aside>
  )
}