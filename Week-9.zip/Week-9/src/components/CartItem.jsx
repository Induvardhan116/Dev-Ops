import { Minus, Plus, X } from 'lucide-react'

const money = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
})

export default function CartItem({ item, quantity, price, onQuantityChange, onRemove }) {
  return (
    <li className="cart-item">
      <div className={`cart-thumb tone-${item.tone}`}>
        <img src={item.image} alt="" />
      </div>
      <div className="cart-item-info">
        <div className="cart-item-topline">
          <div>
            <h3>{item.name}</h3>
            <span className="cart-item-category">{item.category} · {item.id}</span>
          </div>
          <button className="remove-button" type="button" onClick={() => onRemove(item.id)} aria-label={`Remove ${item.name}`} title="Remove item">
            <X size={16} />
          </button>
        </div>
        <div className="cart-item-bottomline">
          <div className="quantity-control" aria-label={`Quantity for ${item.name}`}>
            <button type="button" onClick={() => onQuantityChange(item.id, quantity - 1)} disabled={quantity <= 1} aria-label={`Decrease ${item.name} quantity`}>
              <Minus size={13} />
            </button>
            <span aria-live="polite">{quantity}</span>
            <button type="button" onClick={() => onQuantityChange(item.id, quantity + 1)} disabled={quantity >= item.quantity} aria-label={`Increase ${item.name} quantity`}>
              <Plus size={13} />
            </button>
          </div>
          <strong>{money.format(price * quantity)}</strong>
        </div>
      </div>
    </li>
  )
}