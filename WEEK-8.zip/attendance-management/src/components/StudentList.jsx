import StudentCard from './StudentCard'

function StudentList({ students, onUpdateAttendance }) {
  if (!students.length) {
    return <div className="empty-state">No students match your search.</div>
  }

  return (
    <section className="student-list" aria-label="Student list">
      {students.map((student) => (
        <StudentCard
          key={student.id}
          student={student}
          onUpdateAttendance={onUpdateAttendance}
        />
      ))}
    </section>
  )
}

export default StudentList
