import Attendance from './Attendance'

function StudentCard({ student, onUpdateAttendance }) {
  const isEligible = student.attendancePercent >= 75
  const statusLabel = isEligible ? 'Eligible' : 'Not Eligible'

  return (
    <article className={`student-card ${isEligible ? 'eligible' : 'warning'}`}>
      <div className="student-card__header">
        <div className="student-avatar">{student.name.charAt(0)}</div>
        <div>
          <h3>{student.name}</h3>
          <p>{student.branch}</p>
        </div>
      </div>

      <div className="student-meta">
        <span>Roll No: {student.rollNumber}</span>
        <span>Branch: {student.branch}</span>
      </div>

      <Attendance student={student} onUpdateAttendance={onUpdateAttendance} />

      <span className={`student-eligibility ${isEligible ? 'eligible' : 'warning'}`}>
        {statusLabel}
      </span>
    </article>
  )
}

export default StudentCard
