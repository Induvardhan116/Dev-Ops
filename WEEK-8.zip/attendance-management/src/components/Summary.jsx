function Summary({ totalStudents, presentStudents, absentStudents, averageAttendance, eligibleStudents }) {
  return (
    <section className="summary-grid" aria-label="Attendance summary">
      <div className="summary-card">
        <h2>Total Students: {totalStudents}</h2>
      </div>

      <div className="summary-card">
        <h2>Present Students: {presentStudents}</h2>
      </div>

      <div className="summary-card">
        <h2>Absent Students: {absentStudents}</h2>
      </div>

      <div className="summary-card">
        <h2>Average Attendance: {averageAttendance}%</h2>
      </div>

      <div className="summary-card">
        <h2>Eligible Students: {eligibleStudents}</h2>
      </div>
    </section>
  )
}

export default Summary
