function Attendance({ student, onUpdateAttendance }) {
  return (
    <div className="attendance-box">
      <div className="attendance-box__header">
        <h4>Attendance</h4>
        <strong>{student.attendancePercent}%</strong>
      </div>

      <div className="attendance-actions">
        <button
          type="button"
          className={student.attendanceStatus === 'Present' ? 'active' : ''}
          onClick={() => onUpdateAttendance(student.id, 'Present')}
        >
          Present
        </button>
        <button
          type="button"
          className={student.attendanceStatus === 'Absent' ? 'active' : ''}
          onClick={() => onUpdateAttendance(student.id, 'Absent')}
        >
          Absent
        </button>
      </div>
    </div>
  )
}

export default Attendance
