import { fireEvent, render, screen, within } from '@testing-library/react'
import App from './App'

describe('Student attendance dashboard', () => {
  it('renders the app title and updates the present count when a student is marked present', () => {
    render(<App />)

    expect(screen.getByRole('heading', { name: /student attendance management system/i })).toBeInTheDocument()
    expect(screen.getByText(/present students: 3/i)).toBeInTheDocument()

    const kabirCard = screen.getByText(/kabir singh/i).closest('article')
    fireEvent.click(within(kabirCard).getByRole('button', { name: /present/i }))

    expect(screen.getByText(/present students: 4/i)).toBeInTheDocument()
  })
})
