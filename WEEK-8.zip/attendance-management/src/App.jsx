import { useMemo, useState } from 'react'
import './App.css'
import Header from './components/Header'
import StudentList from './components/StudentList'
import Summary from './components/Summary'

const initialStudents = [
  { id: 1, name: 'Aarav Sharma', rollNumber: 'CS-101', branch: 'Computer Science', attendancePercent: 92, attendanceStatus: 'Present' },
  { id: 2, name: 'Diya Patel', rollNumber: 'EC-204', branch: 'Electronics', attendancePercent: 76, attendanceStatus: 'Present' },
  { id: 3, name: 'Kabir Singh', rollNumber: 'ME-315', branch: 'Mechanical', attendancePercent: 68, attendanceStatus: 'Absent' },
  { id: 4, name: 'Naina Verma', rollNumber: 'IT-420', branch: 'Information Technology', attendancePercent: 84, attendanceStatus: 'Present' },
  { id: 5, name: 'Rohit Kumar', rollNumber: 'EE-118', branch: 'Electrical', attendancePercent: 72, attendanceStatus: 'Absent' },
]

function App() {
  const [students, setStudents] = useState(initialStudents)
  const [searchTerm, setSearchTerm] = useState('')

  const filteredStudents = useMemo(
    () =>
      students.filter((student) =>
        `${student.name} ${student.rollNumber}`
          .toLowerCase()
          .includes(searchTerm.trim().toLowerCase()),
      ),
    [students, searchTerm],
  )

  const presentStudents = students.filter((student) => student.attendanceStatus === 'Present').length
  const absentStudents = students.filter((student) => student.attendanceStatus === 'Absent').length
  const averageAttendance = Math.round(
    students.reduce((sum, student) => sum + student.attendancePercent, 0) / students.length,
  )
  const eligibleStudents = students.filter((student) => student.attendancePercent >= 75).length

  const updateAttendance = (studentId, status) => {
    setStudents((currentStudents) =>
      currentStudents.map((student) => {
        if (student.id !== studentId) {
          return student
        }

        const nextPercent =
          status === 'Present'
            ? Math.min(100, student.attendancePercent + 5)
            : Math.max(0, student.attendancePercent - 5)

        return {
          ...student,
          attendancePercent: nextPercent,
          attendanceStatus: status,
        }
      }),
    )
  }

  const handleResetAttendance = () => {
    setStudents(initialStudents.map((student) => ({ ...student })))
  }

  return (
    <div className="app-shell">
      <Header title="Student Attendance Management System" />

      <Summary
        totalStudents={students.length}
        presentStudents={presentStudents}
        absentStudents={absentStudents}
        averageAttendance={averageAttendance}
        eligibleStudents={eligibleStudents}
      />

      <div className="toolbar">
        <label className="search-box" htmlFor="student-search">
          <span>Search student</span>
          <input
            id="student-search"
            type="text"
            placeholder="Search by name or roll number"
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
          />
        </label>

        <button type="button" className="reset-button" onClick={handleResetAttendance}>
          Reset Attendance
        </button>
      </div>

      <StudentList students={filteredStudents} onUpdateAttendance={updateAttendance} />
    </div>
  )
}

export default App
